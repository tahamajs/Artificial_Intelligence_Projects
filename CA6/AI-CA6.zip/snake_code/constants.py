SNAKE_1_Q_TABLE = "s1_qtble.npy"
SNAKE_2_Q_TABLE = "s2_qtble.npy"

WIDTH = 500
HEIGHT = 500

ROWS = 20
