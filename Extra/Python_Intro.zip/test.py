import numpy
a = []

for i in range(20):
    for j in range(20):
        for k in range(20):
            a.append((i,j,k))

b = (1.5, 5.6 , 9.8)

a = numpy.array(a)
d = ((a-b)**2).sum(axis=1)
ndx = d.argsort()
print(a[ndx[:5]], d[ndx[:5]])